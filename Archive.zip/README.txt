﻿Tarik Krestalica

Game: Speed Math Test!

    Description: Up for a little math? Are you confident in your abilities?
Then the Speed Math Test is perfect for you! The objective of the game is to
answer 5 math problems, with each one chosen at random, and you have one
opportunity to answer each question. You are timed as soon as the game starts! 

    Here's how to play!
        1. You will be asked 5 random arithmetic questions
        2. You are entitled to one answer per question
        3. Your answers must be in number form(no random text, characters, or numbers in words)
            Ex: 76, 43, 2, 8 are acceptable
                hi, bye, eight, seven, or / aren't acceptable
        4. Your answers will be inputted on the same line as the problem,
            then hit the return key to move on to the next question!
        5. Have Fun!
        

End of Game: After the conclusion of the game, you will then be notified on the
amount of time you took to answer each of the 5 arithmetic questions. In addition,
your score is based on the number of questions you got right out of 5! Afterwards,
based on the number of questions you get right, you will then receive a message regarding
how you did.

    To play, go to the Program.cs file and click the play button on the top left-hand
corner! Good Luck!
